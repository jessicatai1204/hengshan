# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Hengshan::Application.config.secret_token = '60fdd37c852c6b27e1417a9de085c4e1cedb001dab348ce399bf199eb12aa45c4ec64611a858716fdaecbbcb757264a60d1a77f146cd8567b1cce777869650ac'
