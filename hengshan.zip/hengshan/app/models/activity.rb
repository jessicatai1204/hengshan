class Activity < ActiveRecord::Base
end
